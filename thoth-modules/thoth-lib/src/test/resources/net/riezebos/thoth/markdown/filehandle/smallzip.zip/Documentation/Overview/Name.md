# What kind of a name is that?!
Yes, Thoth is not the easiest word to pronounce. (Unless copious amounts of beer are consumed because then almost anything you say automatically sounds like ‘Thoth’). When sobered up however it turns out that typing the name Thoth with your keyboard is remarkably easy. Just try it and I think you will agree. Easily writing down something that is not immediately clear when spoken is at the center of what makes a good documentation system. And it turns out that Thoth is also an Egyptian deity that (among a lot of other things) served as a Scribe to the Gods (Ok you got me there).



